import Vue from 'vue'
import VueRouter from 'vue-router'
import AdminLogin from '../views/AdminLogin.vue'
import AdminView from '../views/AdminView.vue'
import UserSignUp from "@/views/UserSignUp";
import UserView from "@/views/UserView";
import UserLogin from "@/views/UserLogin";
import MyTest from "@/views/MyTest";
import CreateOrderPage from "@/components/mainpage/goodspage/BuyPage";

Vue.use(VueRouter)

const routes = [
  {
    path: '/goods',
    name: 'goods',
    component: UserView
  },
  {
    path: '/orders',
    name: 'orders',
    component: UserView,

  },
  {
    path: '/good/:id',
    name: 'good',
    component: UserView,
  },
  {
    path: '/order/:outTradeNo',
    name: 'order',
    component: UserView,
  },
  {
    path: '/login',
    name: 'UserLogin',
    component: UserLogin
  },
  {
    path: '/signup',
    name: 'UserSignUp',
    component: UserSignUp
  },
  {
    path: '/admin',
    name: 'admin',
    component: AdminLogin
  },
  {
    path: '/test',
    name: 'test',
    component: MyTest
  },
  {
    path: '/dashboard',
    name: 'AdminView',
    component: AdminView
  },
]

const router = new VueRouter({
  routes
})

router.beforeEach((to, from, next) =>{
  const token = localStorage.getItem('token')
  if (to.path === '/'){
    next('/goods')
  }
  if (!token && to.path === '/dashboard'){
    next('/admin')
  }else {
    next()
  }
})

export default router
