<template>
  <div class="row mb-3 mb-md-0">
    <div class="col-12 mb-sm-4">
      <div class="ant-carousel">
        <div class="slick-slider slick-initialized" dir="ltr">
          <div class="slick-list" id="slickList" ref="slickList">
            <div class="slick-track" style="width: 6188px; opacity: 1; transform: translate3d(-884px, 0px, 0px);">
              <div data-index="-1" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true"
                   style="width: 897px;">
                <div>
                  <div tabindex="-1" style="width: 100%; display: inline-block;"><a
                      class="block block-rounded bg-image mb-0 v2board-bg-pixels" href="javascript:void(0)"
                      style="background-image: url(&quot;https://i.loli.net/2021/07/31/cBXmwh8YvW4peSF.png&quot;); background-size: cover;">
                    <div class="block-content bg-black-50">
                      <div class="mb-5 mb-sm-7 d-sm-flex justify-content-sm-between align-items-sm-center"><p><span
                          class="badge badge-danger p-2 text-uppercase">公告</span></p></div>
                      <p class="font-size-lg text-white mb-1">使用须知</p>
                      <p class="font-w600 text-white-75">2020-05-26</p></div>
                  </a></div>
                </div>
              </div>
              <div data-index="0" class="slick-slide slick-active slick-current" tabindex="-1" aria-hidden="false"
                   :style=realPicWidth>
                <div>
                  <div tabindex="-1" style="width: 100%; display: inline-block;"><a
                      class="block block-rounded bg-image mb-0 v2board-bg-pixels" href="javascript:void(0)"
                      style="background-image: url(&quot;https://i.loli.net/2021/07/31/cBXmwh8YvW4peSF.png&quot;); background-size: cover;">
                    <div class="block-content bg-black-50">
                      <div class="mb-5 mb-sm-7 d-sm-flex justify-content-sm-between align-items-sm-center"><p><span
                          class="badge badge-danger p-2 text-uppercase">公告</span></p></div>
                      <p class="font-size-lg text-white mb-1">网址列表</p>
                      <p class="font-w600 text-white-75">2022-08-03</p></div>
                  </a></div>
                </div>
              </div>
              <div data-index="1" class="slick-slide" tabindex="-1" aria-hidden="true"
                   :style=realPicWidth>
                <div>
                  <div tabindex="-1" style="width: 100%; display: inline-block;"><a
                      class="block block-rounded bg-image mb-0 v2board-bg-pixels" href="javascript:void(0)"
                      style="background-image: url(&quot;https://i.loli.net/2021/07/31/cBXmwh8YvW4peSF.png&quot;); background-size: cover;">
                    <div class="block-content bg-black-50">
                      <div class="mb-5 mb-sm-7 d-sm-flex justify-content-sm-between align-items-sm-center"><p><span
                          class="badge badge-danger p-2 text-uppercase">公告</span></p></div>
                      <p class="font-size-lg text-white mb-1">流量审计</p>
                      <p class="font-w600 text-white-75">2022-02-01</p></div>
                  </a></div>
                </div>
              </div>
              <div data-index="2" class="slick-slide" tabindex="-1" aria-hidden="true"
                   :style=realPicWidth>
                <div>
                  <div tabindex="-1" style="width: 100%; display: inline-block;"><a
                      class="block block-rounded bg-image mb-0 v2board-bg-pixels" href="javascript:void(0)"
                      style="background-image: url(&quot;https://i.loli.net/2021/07/31/cBXmwh8YvW4peSF.png&quot;); background-size: cover;">
                    <div class="block-content bg-black-50">
                      <div class="mb-5 mb-sm-7 d-sm-flex justify-content-sm-between align-items-sm-center"><p><span
                          class="badge badge-danger p-2 text-uppercase">公告</span></p></div>
                      <p class="font-size-lg text-white mb-1">使用须知</p>
                      <p class="font-w600 text-white-75">2020-05-26</p></div>
                  </a></div>
                </div>
              </div>
              <div data-index="3" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true"
                   :style=picWidth>
                <div>
                  <div tabindex="-1" style="width: 100%; display: inline-block;"><a
                      class="block block-rounded bg-image mb-0 v2board-bg-pixels" href="javascript:void(0)"
                      style="background-image: url(&quot;https://i.loli.net/2021/07/31/cBXmwh8YvW4peSF.png&quot;); background-size: cover;">
                    <div class="block-content bg-black-50">
                      <div class="mb-5 mb-sm-7 d-sm-flex justify-content-sm-between align-items-sm-center"><p><span
                          class="badge badge-danger p-2 text-uppercase">公告</span></p></div>
                      <p class="font-size-lg text-white mb-1">网址列表</p>
                      <p class="font-w600 text-white-75">2022-08-03</p></div>
                  </a></div>
                </div>
              </div>
              <div data-index="4" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true"
                   :style=picWidth>
                <div>
                  <div tabindex="-1" style="width: 100%; display: inline-block;"><a
                      class="block block-rounded bg-image mb-0 v2board-bg-pixels" href="javascript:void(0)"
                      style="background-image: url(&quot;https://i.loli.net/2021/07/31/cBXmwh8YvW4peSF.png&quot;); background-size: cover;">
                    <div class="block-content bg-black-50">
                      <div class="mb-5 mb-sm-7 d-sm-flex justify-content-sm-between align-items-sm-center"><p><span
                          class="badge badge-danger p-2 text-uppercase">公告</span></p></div>
                      <p class="font-size-lg text-white mb-1">流量审计</p>
                      <p class="font-w600 text-white-75">2022-02-01</p></div>
                  </a></div>
                </div>
              </div>
              <div data-index="5" tabindex="-1" class="slick-slide slick-cloned" aria-hidden="true"
                   style=":width: 884px;">
                <div>
                  <div tabindex="-1" style="width: 100%; display: inline-block;"><a
                      class="block block-rounded bg-image mb-0 v2board-bg-pixels" href="javascript:void(0)"
                      style="background-image: url(&quot;https://i.loli.net/2021/07/31/cBXmwh8YvW4peSF.png&quot;); background-size: cover;">
                    <div class="block-content bg-black-50">
                      <div class="mb-5 mb-sm-7 d-sm-flex justify-content-sm-between align-items-sm-center"><p><span
                          class="badge badge-danger p-2 text-uppercase">公告</span></p></div>
                      <p class="font-size-lg text-white mb-1">使用须知</p>
                      <p class="font-w600 text-white-75">2020-05-26</p></div>
                  </a></div>
                </div>
              </div>
            </div>
          </div>
          <ul class="slick-dots slick-dots-bottom" style="display: block;">
            <li class="slick-active">
              <button>1</button>
            </li>
            <li class="">
              <button>2</button>
            </li>
            <li class="">
              <button>3</button>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// import ReSize from "element-resize-detector"

export default {
  name: "NoticeBoard",
  data(){
    return{
      realPicWidth:null,
      picWidth:null
    }
  },
  methods:{
    changeWidth(data){
      console.log(data)
      this.realPicWidth =  "outline: none; width: " + data + "px;"
      this.picWidth = ":width: "+ data +"px;"
    },
  },
  mounted() {
    // this.picWidth =  "outline: none; width: " + 10 + "px;"
    this.changeWidth(this.$refs.slickList.clientWidth)
    const elementResizeDetectorMaker = require("element-resize-detector");
    const erd = elementResizeDetectorMaker();
    erd.listenTo(this.$refs.slickList, function(element) {
      const width = element.offsetWidth;
      console.log("Size: " + width);
      // this.picWidth = width
    });
  }
}
</script>

<style scoped>

</style>
