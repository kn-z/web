<template>
  <div>
    <div class="row" id="cashier">
      <div class="col-md-8 col-sm-12">
        <div class="block block-rounded">
          <div class="block-header block-header-default"><h3 class="block-title v2board-trade-no">商品信息</h3></div>
          <div class="block-content pb-4">
            <div class="v2board-order-info">
              <div><span>产品名称：</span><span>{{ data.Title }}</span></div>
              <div><span>产品单价：</span><span>¥ {{ data.Price }}</span></div>
              <div><span>数量购买：</span><span>{{ data.buyAmount }} 个</span></div>
            </div>
          </div>
        </div>
        <div class="block block-rounded">
          <div class="block-header block-header-default"><h3 class="block-title v2board-trade-no">订单信息</h3>
            <div class="block-options">
              <button type="button" class="btn btn-primary btn-sm btn-danger btn-rounded px-3" @click="closeOrder"> 关闭订单</button>
            </div>
          </div>
          <div class="block-content pb-4">
            <div class="v2board-order-info">
              <div><span>订单号：</span><span>{{ data.outTradeNo }}</span></div>
              <div><span>创建时间：</span><span>{{ data.CreatedAt }}</span></div>
            </div>
          </div>
        </div>
        <div class="block block-rounded js-appear-enabled">
          <div class="block-header block-header-default"><h3 class="block-title">支付方式</h3>
            <div class="block-options"></div>
          </div>
          <div class="block-content p-0">
            <div class="v2board-select active border-primary">
              <div style="flex: 1 1 0%; padding-top: 4px;"><label
                  class="v2board-select-radio ant-radio-wrapper ant-radio-wrapper-checked"><span
                  class="ant-radio ant-radio-checked"><input type="radio" class="ant-radio-input" value=""><span
                  class="ant-radio-inner"></span></span></label>支付宝
              </div>
              <div style="flex: 1 1 0%; text-align: right;"><img height="30" src="https://cdnjs.cloudflare.com/ajax/libs/simple-icons/3.2.0/alipay.svg">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-12">
        <div class="block block-link-pop block-rounded  px-3 py-3 text-light" style="background: rgb(53, 56, 61);"><h5
            class="text-light mb-3">订单总额</h5>
          <div class="row no-gutters pb-3" style="border-bottom: 1px solid rgb(100, 102, 105);">
            <div class="col-8">{{ data.title }} x {{ data.buyAmount }}</div>
          </div>
          <div class="pt-3" style="color: rgb(100, 102, 105);">总计</div>
          <h1 class="text-light mt-3 mb-3">¥ {{ data.totalAmount }} CNY</h1>
          <button type="button" class="btn btn-block btn-primary" @click=Pay><span><i class="far fa-check-circle"></i> 结账 </span>
          </button>
        </div>
      </div>
    </div>
    <div>
      <div class="ant-modal-root">
        <div @click="switchQr" :class="flag?'ant-modal-mask':'ant-modal-mask ant-modal-mask-hidden'"></div>
        <div @click="switchQr" tabindex="-1" class="ant-modal-wrap ant-modal-centered" role="dialog" :style="flag?'':'display: none'">
          <div role="document" class="ant-modal v2board-payment-qrcode" style="width: 300px;">
            <div tabindex="0" aria-hidden="true" style="width: 0px; height: 0px; overflow: hidden; outline: none;"></div>
            <div class="ant-modal-content">
              <div class="ant-modal-body">
                <div id="qrcode" ref="qrcode"></div>
              </div>
              <div class="ant-modal-footer">
                <div style="text-align: center;">等待支付中</div>
              </div>
            </div>
            <div tabindex="0" aria-hidden="true" style="width: 0px; height: 0px; overflow: hidden; outline: none;"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import QRCode from "qrcodejs2";

export default {
  name: "OrderWaited",
  props:["data"],
  data(){
    return{
      flag: 0,
      timer:null,
      status:null,
      router:null,
    }
  },
  watch: {
    $route() {
      this.checkOrder()
      console.log("finish")
    }
  },
  methods:{
    async Pay() {
      const {data: res} = await this.$http.post('pay', {
        "outTradeNo": this.data.outTradeNo,
      })
      this.switchQr()
      this.qrcodeScan(res.qrUrl)
    },

    async closeOrder() {
      await this.$http.put('order/cancel', {
        "outTradeNo": this.data.outTradeNo,
      })
      this.$bus.$emit('reloadOrderPage')
    },

    checkOrder() {
      if (this.data.status === 0) {
        this.timer = setInterval(async () => {
          if (this.$route.fullPath.indexOf("/order/") !== -1) {
            this.router = this.$route.fullPath
            const {data: res} = await this.$http.get("order/" + this.data.outTradeNo)
            if (res.data.status === 1) {
              this.$bus.$emit('switchOrderStatus', 1)
              clearInterval(this.timer)
            }
            if (res.data.status === 2) {
              this.$bus.$emit('switchOrderStatus', 2)
              clearInterval(this.timer)
            }
          } else clearInterval(this.timer);
        }, 3000); // 注意: 第一个参数为方法名的时候不要加括号
      }
    },

    qrcodeScan(qrUrl) { //生成二维码
      new QRCode("qrcode", {
        width: 250, // 二维码宽度
        height: 250, // 二维码高度
        text: qrUrl, // 浏览器地址url
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H,
      })

    },
    clearQrcode() {
      this.$refs.qrcode.innerHTML = ''
    },

    switchQr() {
      this.flag = !this.flag
      this.clearQrcode()
    }
  },
  mounted() {
    this.checkOrder()
  }
}
</script>

<style scoped>

</style>
