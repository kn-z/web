<template>
  <li class="nav-main-item" @click="switchMC">
    <a class="nav-main-link false">
      <i :class=item.icon></i>
      <span class="nav-main-link-name" >{{item.name}}</span>
    </a>
  </li>

</template>

<script>
export default {
  name: "SideBarItem",
  props: ["item"],
  methods:{
    async switchMC(){
      this.$bus.$emit('changeTitle', this.item.name)
      this.$bus.$emit('switchSide', 0)
      switch (this.item.id) {
        case "01":
          if (this.$route.path !== "/goods") {
             await this.$router.push("/goods")
          }
          this.$bus.$emit('switchMainContainer', 1);
          break;
        case "02":
          if (this.$route.path !== "/orders") {
            await this.$router.push("/orders")
          }
          this.$bus.$emit('switchMainContainer', 4)
          break;
      }
    },
  }
}


</script>

<style scoped>

</style>
