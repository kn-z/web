<template>
  <tbody class="ant-table-tbody">
    <OrderItem v-for="order in data"
               :key="order.outTradeNo"
               :order="order"
               />
  </tbody>
</template>

<script>
import OrderItem from "@/components/mainpage/orderlist/OrderItem"


export default {
  name: "OrderList",
  props:['data'],
  data(){
    return{
      orders:null,
    }
  },
  components:{
    OrderItem,
  },
}
</script>

<style scoped>

</style>
