<template>
  <tr class="ant-table-row ant-table-row-level-0" data-row-key="3" style="height: 54px;">
    <td class="" style="text-align: right;">
      <div><a @click="orderInfo">查看详情</a>
        <div class="ant-divider ant-divider-vertical" role="separator"></div>
        <a :disabled="!cancel" href="javascript:void(0);" @click="closeOrder">取消</a></div>
    </td>
  </tr>
</template>

<script>
export default {
  name: "SetItem",
  props: ['order'],
  data() {
    return {
      cancel: null,
    }
  },
  methods: {
    orderInfo() {
      this.$bus.$emit('toOrderInfo', this.order.outTradeNo);
    },
    async closeOrder() {
      await this.$http.put('order/cancel', {
        "outTradeNo": this.order.outTradeNo,
      })
      this.$bus.$emit('reloadOrderListPage')
    },
  },
  mounted() {
    if (this.order.status === "待支付") {
      this.cancel = true
    }
  }
}
</script>

<style scoped>

</style>
