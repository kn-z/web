<template>
  <tr class="ant-table-row ant-table-row-level-0" data-row-key="2">
    <td class=""><a @click="orderInfo">{{ order.outTradeNo }}</a></td>
    <td class="" style="text-align: center;"><span class="ant-tag">{{ order.title }} × {{ order.buyAmount }}</span></td>
    <td class="" style="text-align: right;"><span class="ant-tag">CNY {{ order.totalAmount }}</span></td>
    <td class="">
      <div>
        <span class="ant-badge ant-badge-status ant-badge-not-a-wrapper"><span
          :class="statusStyle"></span><span
          class="ant-badge-status-text"></span></span>{{ order.status }}
      </div>
    </td>
    <td class="">{{ order.CreatedAt }} </td>
    <td class="ant-table-fixed-columns-in-body" style="text-align: right;">
      <div><a href="javascript:void(0);">查看详情</a>
        <div class="ant-divider ant-divider-vertical" role="separator"></div>
        <a disabled="" href="javascript:void(0);">取消</a></div>
    </td>
  </tr>
</template>

<script>
export default {
  name: "OrderItem",
  props:['order'],
  data(){
    return{
      statusStyle:null,
    }
  },
  methods: {
    orderInfo(){
      this.$bus.$emit('toOrderInfo',this.order.outTradeNo);
    },
    formatInfo(){
      let dataForm = this.order
      dataForm.totalAmount = (dataForm.totalAmount/100).toLocaleString('zh', { style: 'currency', currency: 'CNY' }).split('¥')[1];
      dataForm.CreatedAt = this.order.CreatedAt.split('T')[0] + " " + this.order.CreatedAt.split('T')[1].split('.')[0]
      if (dataForm.status === 0) {
        dataForm.status = "待支付"
        this.statusStyle = "ant-badge-status-dot ant-badge-status-error"
      }
      if (dataForm.status === 1) {
        dataForm.status = "已完成"
        this.statusStyle = "ant-badge-status-dot ant-badge-status-success"

      }
      if (dataForm.status === 2) {
        dataForm.status = "已取消"
        this.statusStyle = "ant-badge-status-dot ant-badge-status-default"
      }
    }
  },
  mounted() {
    this.formatInfo()
    this.$bus.$on('reloadOrderItem',()=>{
      this.formatInfo()
    })

  }
}
</script>

<style scoped>

</style>
