<template>
  <main id="main-container">
    <GoodsPage v-if="item===1"/>
    <OrderInfo v-if="item===2"/>
    <CreateOrderPage v-if="item===3"/>

    <OrdersPage v-if="item===4"/>
  </main>
</template>

<script>

import CreateOrderPage from "@/components/mainpage/goodspage/BuyPage";
import GoodsPage from "@/components/mainpage/goodspage/GoodsPage";
import OrderInfo from "@/components/mainpage/orderpage/OrderInfo";
import OrdersPage from "@/components/mainpage/orderlist/OrdersPage";

export default {
  name: "MainContainer",
  components:{
    CreateOrderPage,
    GoodsPage,
    OrderInfo,
    OrdersPage,
  },
  data(){
    return{
      item: 1,
    }
  },
  watch: {
    $route () {
      this.routerHandler()
    }
  },
  methods: {
    routerHandler() {
      if (this.$route.fullPath === '/goods') {
        this.item = 1
      }
      if (this.$route.fullPath.indexOf("/order/") !== -1 ) {
        this.item = 2
      }
      if (this.$route.fullPath.indexOf("/good/") !== -1 ) {
        this.item = 3
      }
      if (this.$route.fullPath.indexOf("/orders") !== -1 ) {
        this.item = 4
      }
    }
  },
  mounted() {
    this.$bus.$on('switchMainContainer',(data)=>{
      this.item = data
    })
    this.routerHandler()
  }
}
</script>

<style scoped>

</style>
