<template>
  <div class="content content-full">
    <div class="spinner-grow text-primary" role="status" v-show="isLoading"><span class="sr-only">Loading...</span></div>
    <div class="row" id="cashier" v-show="!isLoading">
      <div class="col-md-8 col-sm-12">
        <div class="block block-link-pop block-rounded py-3" style="background-color: rgb(255, 255, 255);"><h4
            class="mb-0 px-3">{{ good.title }}</h4>
          <div class="v2board-plan-content">单价¥ {{ good.price }}</div>
          <div class="v2board-plan-content">库存 {{ good.stock}}</div>
        </div>
        <div class="block block-rounded js-appear-enabled">
          <div class="block-header block-header-default"><h3 class="block-title">商品描述</h3>
            <div class="block-options"></div>
          </div>
          <div data-v-42f4bad4="" class="ant-modal-body">
            <div data-v-42f4bad4="" id="qrcode">
              <canvas width="250" height="250" style="display: none;"></canvas>
              <img object-fit="contain"  alt="pic" style="display: block;" :src=good.image>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-12">
        <div class="block block-link-pop block-rounded  px-3 py-3 mb-2 text-light" style="background: rgb(53, 56, 61);">
          <input type="text" class="form-control v2board-input-coupon p-0" placeholder="购买数量" v-model="formData.buyAmount" onkeyup="this.value=this.value.replace(/\D|^0/g,'')">
          <input type="text" class="form-control v2board-input-coupon p-0" placeholder="用户邮箱" v-model="formData.email">

        </div>
        <div class="block block-link-pop block-rounded  px-3 py-3 text-light" style="background: rgb(53, 56, 61);"><h5
            class="text-light mb-3">订单总额</h5>
          <div class="row no-gutters pb-3" style="border-bottom: 1px solid rgb(100, 102, 105);">
            <div class="col-8">¥ {{ good.price }} x {{formData.buyAmount}}</div>
          </div>
          <div class="pt-3" style="color: rgb(100, 102, 105);">总计</div>
          <h1 class="text-light mt-3 mb-3">¥ {{ good.price * formData.buyAmount }}</h1>
          <button type="button" class="btn btn-block btn-primary" @click="createOrder"><span><i
              class="far fa-check-circle"></i> 下单</span>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  inject:['reload'],
  name: "BuyPage",
  data() {
    return {
      formData:{
        email: null,
        goodId: null,
        buyAmount: 0,
      },
      good: {
        title: null,
        content: null,
        price: null,
        stock: null,
        image: null,
      },
      isLoading: true,
    }
  },
  watch: {
    $route () {
      this.isLoading = true
      this.getGood()
    }
  },
  methods: {
    async getGood() {
      if (this.$route.fullPath.indexOf("/good/") !== -1 ) {
        this.formData.goodId = this.$route.fullPath.split('/')[2]
        const {data: res} = await this.$http.get("good/" + this.formData.goodId)
        this.good = res.data
        this.good.price /= 100
        this.isLoading = false
      }
    },

    async createOrder() {
      const {data: res} = await this.$http.post('order/create', {
        "email": this.formData.email,
        "goodId": parseInt(this.formData.goodId),
        "buyAmount": parseInt(this.formData.buyAmount),
      })
      if (res.status !== 200) {
        console.log(res.message)
      } else {
        await this.$router.push({name: 'order', params: {outTradeNo: res.data.outTradeNo}})
        this.$bus.$emit('switchMainContainer', 2);
      }
    },
  },
  mounted(){
    this.getGood()
  }
}
</script>

<style scoped>

</style>
