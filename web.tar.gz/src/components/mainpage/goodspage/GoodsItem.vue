<template>
  <div class="col-md-12 col-xl-4" @click="this.goodInfo"><a class="block block-link-pop block-rounded m-3 mx-xl-0">
    <div class="block-header plan"><h3 class="block-title">{{ good.title }}</h3>
    </div>
    <div class="block-content bg-body">
      <div class="py-2"><p class="h1 mb-2">¥ {{ (good.price/100).toLocaleString('zh', { style: 'currency', currency: 'CNY' }).split('¥')[1] }}</p>
        <p class="h6 text-muted">剩余 {{ good.stock }} 个</p></div></div>
    <div class="block-content py-3">
      <div class="mb-3">
        <p align="center">
          <i style="  color: #495057;">
          </i>{{ good.content }}</p>
      </div>
    </div>
  </a></div>
</template>

<script>
export default {
  name: "GoodsInfo",
  props:["good"],
  methods:{
    async goodInfo(){
      await this.$router.push({name: 'good', params: {id: this.good.ID}})
      this.$bus.$emit('switchMainContainer', 3);
    }
  },
}
</script>

<style scoped>

</style>
