<template>
  <div id="root">
    <div id="page-container" :class="sideBarInfo.sideType">
      <div class="v2board-nav-mask" :style="sideBarInfo.maskShow" @click="CloseSide"></div>
      <SideBar/>
      <PageHeader :title="pageHeaderInfo.title" :email="pageHeaderInfo.email" :isLogin="pageHeaderInfo.isLogin"/>
      <MainContainer/>
    </div>
  </div>
</template>


<script>
import SideBar from "@/components/mainpage/sidebar/SideBar";
import PageHeader from "@/components/mainpage/pageheader/PageHeader";
import MainContainer from "@/components/mainpage/MainContainer";

export default {
  name: "UserView",
  components: {
    PageHeader,
    SideBar,
    MainContainer
  },
  data() {
    return {
      pageHeaderInfo: {
        title: "购买商品",
        email: null,
        isLogin: false,
      },
      sideBarInfo: {
        maskShow: "display: none;",
        sideType: "sidebar-o sidebar-dark page-header-dark side-scroll page-header-fixed main-content-boxed side-trans-enabled false"
      },
    }
  },
  methods: {
    async checkToken() {
      const {data: res} = await this.$http.post('user/info')
      if (res.status === 200) {
        this.pageHeaderInfo.isLogin = true
        this.pageHeaderInfo.email = res.data.email
      } else {
        this.pageHeaderInfo.isLogin = false
        this.pageHeaderInfo.email = "未登录"
      }
    },
    OpenSide() {
      this.sideBarInfo.maskShow = "display: block;"
      this.sideBarInfo.sideType = "sidebar-o sidebar-dark page-header-dark side-scroll page-header-fixed main-content-boxed side-trans-enabled sidebar-o-xs"
    },
    CloseSide() {
      this.sideBarInfo.maskShow = "display: none;"
      this.sideBarInfo.sideType = "sidebar-o sidebar-dark page-header-dark side-scroll page-header-fixed main-content-boxed side-trans-enabled false"
    },
  },
  mounted() {
    this.checkToken()
    this.$bus.$on('switchSide', (data) => {
      if (data === 1) this.OpenSide()
      if (data === 0) this.CloseSide()
    })
    this.$bus.$on('changeTitle', (data) => {
      this.pageHeaderInfo.title = data
    })
  }
}
</script>

<style scoped>

</style>
