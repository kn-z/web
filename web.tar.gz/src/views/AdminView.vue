<template>
  <div id="root">
    <div id="page-container" :class=sideType>
      <div class="v2board-nav-mask" :style="maskShow" @click="CloseSide"></div>
      <SideBar/>
      <PageHeader/>
      <MainContainer/>
    </div>
  </div>
</template>

<script>
import PageHeader from "@/components/mainpage/pageheader/PageHeader";
import SideBar from "@/components/mainpage/sidebar/SideBar";
import MainContainer from "@/components/mainpage/MainContainer";

export default {
  name: "AdminView",
  components: {
    SideBar,
    PageHeader,
    MainContainer
  },
  data(){
    return{
      maskShow: "display: none;",
      sideType:"sidebar-o sidebar-dark page-header-dark side-scroll page-header-fixed main-content-boxed side-trans-enabled false"
    }
  },
  methods:{
    OpenSide(){
      this.maskShow = "display: block;"
      this.sideType = "sidebar-o sidebar-dark page-header-dark side-scroll page-header-fixed main-content-boxed side-trans-enabled sidebar-o-xs"
    },
    CloseSide(){
      this.maskShow = "display: none;"
      this.sideType = "sidebar-o sidebar-dark page-header-dark side-scroll page-header-fixed main-content-boxed side-trans-enabled false"
    }
  },
  mounted() {
    this.$bus.$on('switchSide',(data)=>{
      if (data === 1) this.OpenSide()
      if (data === 0) this.CloseSide()
    })
  }

}

</script>

<style scoped>

</style>
